from VistaLogin import VistaLogin
from VistaExploradorABB import VistaExploradorABB


def iniciar_explorador():
    VistaExploradorABB()


if __name__ == "__main__":
    login = VistaLogin(callback_exito=iniciar_explorador)
    login.ejecutar()
