class NodoArbol:
    """Representa un nodo individual dentro del Árbol Binario de Búsqueda."""
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None


class ArbolBinarioBusqueda:
    """Gestiona las operaciones del ABB, límites de profundidad, búsqueda y recorridos."""
    def __init__(self, niveles_maximos=4):
        self.raiz = None
        self.niveles_maximos = niveles_maximos

    def insertar(self, valor):
        """Inserta un valor entero si no supera el límite de 4 niveles."""
        if self.raiz is None:
            self.raiz = NodoArbol(valor)
            return True, "Nodo raíz agregado exitosamente."
        return self._insertar_recursivo(self.raiz, valor, nivel_actual=1)

    def _insertar_recursivo(self, nodo_actual, valor, nivel_actual):
        if valor == nodo_actual.valor:
            return False, f"El nodo {valor} ya existe en el árbol."

        if nivel_actual >= self.niveles_maximos:
            return False, f"No se puede insertar el nodo {valor}.\nEl árbol está limitado a {self.niveles_maximos} niveles.\nLimpie el árbol o elija un valor diferente."

        if valor < nodo_actual.valor:
            if nodo_actual.izquierda is None:
                nodo_actual.izquierda = NodoArbol(valor)
                return True, f"Nodo {valor} agregado exitosamente."
            return self._insertar_recursivo(nodo_actual.izquierda, valor, nivel_actual + 1)
        else:
            if nodo_actual.derecha is None:
                nodo_actual.derecha = NodoArbol(valor)
                return True, f"Nodo {valor} agregado exitosamente."
            return self._insertar_recursivo(nodo_actual.derecha, valor, nivel_actual + 1)

    def buscar(self, valor):
        """Busca un nodo y retorna (booleano_encontrado, lista_ruta_visitada)."""
        ruta = []
        actual = self.raiz
        while actual is not None:
            ruta.append(actual.valor)
            if valor == actual.valor:
                return True, ruta
            elif valor < actual.valor:
                actual = actual.izquierda
            else:
                actual = actual.derecha
        return False, ruta

    def limpiar(self):
        """Reinicia todo el árbol binario."""
        self.raiz = None

    def obtener_preorden(self):
        resultado = []
        self._preorden(self.raiz, resultado)
        return resultado

    def _preorden(self, nodo, resultado):
        if nodo:
            resultado.append(nodo.valor)
            self._preorden(nodo.izquierda, resultado)
            self._preorden(nodo.derecha, resultado)

    def obtener_inorden(self):
        resultado = []
        self._inorden(self.raiz, resultado)
        return resultado

    def _inorden(self, nodo, resultado):
        if nodo:
            self._inorden(nodo.izquierda, resultado)
            resultado.append(nodo.valor)
            self._inorden(nodo.derecha, resultado)

    def obtener_posorden(self):
        resultado = []
        self._posorden(self.raiz, resultado)
        return resultado

    def _posorden(self, nodo, resultado):
        if nodo:
            self._posorden(nodo.izquierda, resultado)
            self._posorden(nodo.derecha, resultado)
            resultado.append(nodo.valor)

    def obtener_estadisticas(self):
        """Retorna (total_nodos, altura_actual, valor_raiz)."""
        nodos = len(self.obtener_inorden())
        altura = self._calcular_altura(self.raiz)
        valor_raiz = self.raiz.valor if self.raiz else "-"
        return nodos, altura, valor_raiz

    def _calcular_altura(self, nodo):
        if nodo is None:
            return 0
        return 1 + max(self._calcular_altura(nodo.izquierda), self._calcular_altura(nodo.derecha))
