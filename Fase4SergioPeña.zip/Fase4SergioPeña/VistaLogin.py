import tkinter as tk
from tkinter import messagebox
from datetime import datetime


class VistaLogin:
    def __init__(self, callback_exito):
        self.callback_exito = callback_exito
        self.root = tk.Tk()
        self.root.title("Fase4SergioPeña - Acceso")
        self.root.geometry("430x380")
        self.root.resizable(False, False)
        self.root.configure(bg="#0F172A")

        self._construir_interfaz()

    def _construir_interfaz(self):
        tk.Label(self.root, text="🌲 Explorador ABB", font=("Segoe UI", 20, "bold"), bg="#0F172A", fg="#38BDF8").pack(pady=(25, 2))
        tk.Label(self.root, text="Árbol Binario de Búsqueda — Fase 4", font=("Segoe UI", 10), bg="#0F172A", fg="#94A3B8").pack(pady=(0, 15))

        tarjeta = tk.Frame(self.root, bg="#1E293B", padx=15, pady=12, highlightbackground="#334155", highlightthickness=1)
        tarjeta.pack(fill=tk.X, padx=30, pady=5)

        detalles = [
            ("Aplicación:", "Fase4SergioPeña"),
            ("Estudiante:", "Sergio Hernan Peña Guzman"),
            ("Curso:", "Estructura de Datos · 301305"),
            ("Fecha:", datetime.now().strftime("%d/%m/%Y"))
        ]
        for idx, (etiqueta, val) in enumerate(detalles):
            tk.Label(tarjeta, text=etiqueta, font=("Segoe UI", 9, "bold"), bg="#1E293B", fg="#94A3B8").grid(row=idx, column=0, sticky="w", pady=2)
            tk.Label(tarjeta, text=val, font=("Segoe UI", 9), bg="#1E293B", fg="#F8FAFC").grid(row=idx, column=1, sticky="w", padx=10, pady=2)

        tk.Label(self.root, text="Ingrese la Contraseña", font=("Segoe UI", 10, "bold"), bg="#0F172A", fg="#E2E8F0").pack(anchor="w", padx=30, pady=(15, 4))
        self.entry_pass = tk.Entry(self.root, show="-", font=("Segoe UI", 12), bg="#1E293B", fg="#38BDF8", insertbackground="white", relief="flat", highlightbackground="#38BDF8", highlightthickness=1)
        self.entry_pass.pack(fill=tk.X, padx=30, ipady=5)
        self.entry_pass.bind("<Return>", lambda e: self.validar_login())

        tk.Label(self.root, text="Contraseña enmascarada (----)", font=("Segoe UI", 8), bg="#0F172A", fg="#64748B").pack(anchor="w", padx=30, pady=(2, 15))

        tk.Button(
            self.root, text="Ingresar al Explorador ABB  →", font=("Segoe UI", 10, "bold"),
            bg="#0284C7", fg="white", activebackground="#0369A1", activeforeground="white",
            relief="flat", cursor="hand2", command=self.validar_login
        ).pack(fill=tk.X, padx=30, ipady=7)

    def validar_login(self):
        if self.entry_pass.get() == "UNAD":
            self.root.destroy()
            self.callback_exito()
        else:
            messagebox.showerror("Acceso Denegado", "Contraseña incorrecta. Por favor ingrese la clave institucional.")

    def ejecutar(self):
        self.root.mainloop()
