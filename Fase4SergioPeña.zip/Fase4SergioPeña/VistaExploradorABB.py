import tkinter as tk
from tkinter import messagebox
from EstructuraArbol import ArbolBinarioBusqueda


class VistaExploradorABB:
    def __init__(self):
        self.abb = ArbolBinarioBusqueda(niveles_maximos=4)
        self.ruta_busqueda = []
        self.nodo_encontrado = None

        self.window = tk.Tk()
        self.window.title("Fase4SergioPeña — Explorador ABB")
        self.window.geometry("1120x680")
        self.window.configure(bg="#0F172A")

        self._construir_interfaz()
        self.redibujar_todo()
        self.window.mainloop()

    def _construir_interfaz(self):
        barra_superior = tk.Frame(self.window, bg="#1E293B", height=42)
        barra_superior.pack(fill=tk.X)
        tk.Label(barra_superior, text="🌲 Explorador ABB  |  Árbol Binario de Búsqueda", font=("Segoe UI", 11, "bold"), bg="#1E293B", fg="#38BDF8").pack(side=tk.LEFT, padx=15, pady=8)
        tk.Label(barra_superior, text="Sergio Hernan Peña Guzman  |  Estructura de Datos 301305", font=("Segoe UI", 9), bg="#1E293B", fg="#94A3B8").pack(side=tk.RIGHT, padx=15)

        contenedor_principal = tk.Frame(self.window, bg="#0F172A")
        contenedor_principal.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        barra_lateral = tk.Frame(contenedor_principal, bg="#1E293B", width=230, padx=14, pady=14, highlightbackground="#334155", highlightthickness=1)
        barra_lateral.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 12))
        barra_lateral.pack_propagate(False)

        tk.Label(barra_lateral, text="⚙ Controles", font=("Segoe UI", 11, "bold"), bg="#1E293B", fg="#38BDF8").pack(anchor="w", pady=(0, 10))
        tk.Label(barra_lateral, text="Valor del Nodo (Entero)", font=("Segoe UI", 9), bg="#1E293B", fg="#CBD5E1").pack(anchor="w")

        self.entry_valor = tk.Entry(barra_lateral, font=("Segoe UI", 12, "bold"), justify="center", bg="#0F172A", fg="white", insertbackground="white", relief="flat", highlightbackground="#475569", highlightthickness=1)
        self.entry_valor.pack(fill=tk.X, pady=(4, 12), ipady=4)
        self.entry_valor.bind("<Return>", lambda e: self.manejar_agregar_nodo())

        botones = [
            ("+ Agregar Nodo", "#0284C7", self.manejar_agregar_nodo),
            ("🔍 Buscar Nodo", "#0D9488", self.manejar_buscar_nodo),
            ("🧹 Limpiar", "#D97706", self.manejar_limpiar_arbol),
            ("🚪 Salir", "#DC2626", self.window.quit)
        ]
        for texto, color, cmd in botones:
            tk.Button(
                barra_lateral, text=texto, font=("Segoe UI", 9, "bold"), bg=color, fg="white",
                relief="flat", cursor="hand2", command=cmd
            ).pack(fill=tk.X, pady=4, ipady=4)

        marco_estadisticas = tk.LabelFrame(barra_lateral, text=" Estadísticas del Árbol ", font=("Segoe UI", 9, "bold"), bg="#1E293B", fg="#94A3B8", padx=10, pady=8)
        marco_estadisticas.pack(fill=tk.X, pady=(18, 10))

        self.lbl_nodos = tk.Label(marco_estadisticas, text="Nodos: 0", font=("Consolas", 9), bg="#1E293B", fg="#E2E8F0")
        self.lbl_nodos.pack(anchor="w")
        self.lbl_altura = tk.Label(marco_estadisticas, text="Altura: 0", font=("Consolas", 9), bg="#1E293B", fg="#E2E8F0")
        self.lbl_altura.pack(anchor="w")
        self.lbl_raiz = tk.Label(marco_estadisticas, text="Raíz: -", font=("Consolas", 9), bg="#1E293B", fg="#E2E8F0")
        self.lbl_raiz.pack(anchor="w")

        marco_leyenda = tk.LabelFrame(barra_lateral, text=" Leyenda ", font=("Segoe UI", 9, "bold"), bg="#1E293B", fg="#94A3B8", padx=10, pady=8)
        marco_leyenda.pack(fill=tk.X, pady=5)

        leyendas = [
            ("● Nodo Regular", "#0284C7"),
            ("● Nodo Encontrado", "#10B981"),
            ("● Ruta de Búsqueda", "#F59E0B"),
            ("● Nodo de Recorrido", "#EAB308")
        ]
        for texto, col in leyendas:
            tk.Label(marco_leyenda, text=texto, font=("Segoe UI", 8, "bold"), bg="#1E293B", fg=col).pack(anchor="w", pady=1)

        area_paneles = tk.Frame(contenedor_principal, bg="#0F172A")
        area_paneles.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        caja_arbol = tk.Frame(area_paneles, bg="#1E293B", highlightbackground="#334155", highlightthickness=1)
        caja_arbol.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        tk.Label(caja_arbol, text="🌲 Árbol Binario de Búsqueda (Máx. 4 Niveles)", font=("Segoe UI", 9, "bold"), bg="#1E293B", fg="#38BDF8").pack(anchor="w", padx=10, pady=5)
        self.canvas_arbol = tk.Canvas(caja_arbol, bg="#0B1120", highlightthickness=0)
        self.canvas_arbol.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self.canvas_arbol.bind("<Configure>", lambda e: self.redibujar_todo())

        fila_recorridos = tk.Frame(area_paneles, bg="#0F172A", height=130)
        fila_recorridos.pack(fill=tk.X)
        fila_recorridos.pack_propagate(False)

        self.canvas_pre = self._crear_panel_recorrido(fila_recorridos, "● Preorden", 0)
        self.canvas_in = self._crear_panel_recorrido(fila_recorridos, "● Inorden", 1)
        self.canvas_pos = self._crear_panel_recorrido(fila_recorridos, "● Posorden", 2)

        self.estado_var = tk.StringVar(value="Listo. Ingrese un valor entero y haga clic en Agregar Nodo.")
        tk.Label(self.window, textvariable=self.estado_var, font=("Segoe UI", 8), bg="#1E293B", fg="#94A3B8", anchor="w", padx=12).pack(fill=tk.X, side=tk.BOTTOM)

    def _crear_panel_recorrido(self, padre, titulo, col_idx):
        padre.columnconfigure(col_idx, weight=1)
        caja = tk.Frame(padre, bg="#1E293B", highlightbackground="#334155", highlightthickness=1)
        caja.grid(row=0, column=col_idx, sticky="nsew", padx=(0 if col_idx == 0 else 6, 0))
        tk.Label(caja, text=titulo, font=("Segoe UI", 9, "bold"), bg="#1E293B", fg="#38BDF8").pack(anchor="w", padx=8, pady=4)
        canvas = tk.Canvas(caja, bg="#0B1120", highlightthickness=0)
        canvas.pack(fill=tk.BOTH, expand=True, padx=6, pady=(0, 6))
        return canvas

    def manejar_agregar_nodo(self):
        valor_crudo = self.entry_valor.get().strip()
        self.entry_valor.delete(0, tk.END)
        self.ruta_busqueda = []
        self.nodo_encontrado = None

        try:
            val = int(valor_crudo)
        except ValueError:
            messagebox.showerror("Entrada Inválida", f"'{valor_crudo}' no es un número entero válido.\nSolo se aceptan números enteros (ej. 50, 30, 70).")
            self.estado_var.set("Error: El dato ingresado debe ser un número entero válido.")
            return

        exito, mensaje = self.abb.insertar(val)
        if not exito:
            messagebox.showerror("Profundidad Máxima Alcanzada", mensaje)
            self.estado_var.set(f"Acción bloqueada: {mensaje.splitlines()[0]}")
            return

        self.estado_var.set(mensaje)
        self.redibujar_todo()

    def manejar_buscar_nodo(self):
        valor_crudo = self.entry_valor.get().strip()
        try:
            val = int(valor_crudo)
        except ValueError:
            messagebox.showerror("Entrada Inválida", f"'{valor_crudo}' no es un número entero válido.\nIngrese un número válido para buscar.")
            return

        if self.abb.raiz is None:
            messagebox.showwarning("Árbol Vacío", "El Árbol Binario de Búsqueda se encuentra vacío.")
            return

        encontrado, ruta = self.abb.buscar(val)
        self.ruta_busqueda = ruta
        self.nodo_encontrado = val if encontrado else None
        self.redibujar_todo()

        ruta_str = " -> ".join(map(str, ruta))
        if encontrado:
            messagebox.showinfo("Nodo Encontrado", f"¡El nodo {val} fue encontrado en el árbol!\nRuta de búsqueda: {ruta_str}")
            self.estado_var.set(f"Nodo {val} encontrado. Ruta: {ruta_str}")
        else:
            messagebox.showwarning("Nodo No Encontrado", f"El nodo {val} no existe en el árbol.\nRuta visitada: {ruta_str}")
            self.estado_var.set(f"El nodo {val} no existe en el árbol.")

    def manejar_limpiar_arbol(self):
        self.abb.limpiar()
        self.ruta_busqueda = []
        self.nodo_encontrado = None
        self.entry_valor.delete(0, tk.END)
        self.redibujar_todo()
        self.estado_var.set("Árbol limpiado exitosamente.")

    def redibujar_todo(self):
        self.canvas_arbol.delete("all")
        w = self.canvas_arbol.winfo_width()
        h = self.canvas_arbol.winfo_height()

        if self.abb.raiz is None:
            self.canvas_arbol.create_text(w // 2, h // 2, text="Árbol Vacío", fill="#475569", font=("Segoe UI", 12, "italic"))
        else:
            self._dibujar_nodo_arbol(self.abb.raiz, w // 2, 40, w // 4, 75)

        self._dibujar_nodos_recorrido(self.canvas_pre, self.abb.obtener_preorden(), "Sin datos en preorden")
        self._dibujar_nodos_recorrido(self.canvas_in, self.abb.obtener_inorden(), "Sin datos en inorden")
        self._dibujar_nodos_recorrido(self.canvas_pos, self.abb.obtener_posorden(), "Sin datos en posorden")

        nodos, altura, valor_raiz = self.abb.obtener_estadisticas()
        self.lbl_nodos.config(text=f"Nodos: {nodos}")
        self.lbl_altura.config(text=f"Altura: {altura}")
        self.lbl_raiz.config(text=f"Raíz: {valor_raiz}")

    def _dibujar_nodo_arbol(self, nodo, x, y, dx, dy):
        r = 18
        if nodo.izquierda:
            lx, ly = x - dx, y + dy
            color_linea = "#F59E0B" if (nodo.valor in self.ruta_busqueda and nodo.izquierda.valor in self.ruta_busqueda) else "#475569"
            self.canvas_arbol.create_line(x, y, lx, ly, fill=color_linea, width=2)
            self._dibujar_nodo_arbol(nodo.izquierda, lx, ly, dx // 2, dy)

        if nodo.derecha:
            rx, ry = x + dx, y + dy
            color_linea = "#F59E0B" if (nodo.valor in self.ruta_busqueda and nodo.derecha.valor in self.ruta_busqueda) else "#475569"
            self.canvas_arbol.create_line(x, y, rx, ry, fill=color_linea, width=2)
            self._dibujar_nodo_arbol(nodo.derecha, rx, ry, dx // 2, dy)

        color_relleno = "#0284C7"
        if nodo.valor == self.nodo_encontrado:
            color_relleno = "#10B981"
        elif nodo.valor in self.ruta_busqueda:
            color_relleno = "#F59E0B"

        self.canvas_arbol.create_oval(x - r, y - r, x + r, y + r, fill=color_relleno, outline="#E0F2FE", width=2)
        self.canvas_arbol.create_text(x, y, text=str(nodo.valor), fill="white", font=("Segoe UI", 9, "bold"))

    def _dibujar_nodos_recorrido(self, canvas, elementos, texto_vacio):
        canvas.delete("all")
        canvas.update_idletasks()
        w = canvas.winfo_width() if canvas.winfo_width() > 1 else 260
        h = canvas.winfo_height() if canvas.winfo_height() > 1 else 80

        if not elementos:
            canvas.create_text(w // 2, h // 2, text=texto_vacio, fill="#475569", font=("Segoe UI", 9, "italic"))
            return

        r = 11
        espaciado = min(26, (w - 24) // max(len(elementos), 1))
        inicio_x = (w - (espaciado * (len(elementos) - 1))) // 2

        for idx, val in enumerate(elementos):
            cx = inicio_x + idx * espaciado
            cy = h // 2
            if idx > 0:
                canvas.create_line(cx - espaciado, cy, cx, cy, fill="#64748B", width=1.5)
            canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill="#EAB308", outline="#FEF08A", width=1)
            canvas.create_text(cx, cy, text=str(val), fill="#0F172A", font=("Segoe UI", 7, "bold"))
